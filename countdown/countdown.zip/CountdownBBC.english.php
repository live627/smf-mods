<?php

$txt['countdown'] = 'Countdown (Example [countdown=8,14,2009,13,23]Text[/countdown])';
$txt['cd_year'] = ' year';
$txt['cd_years'] = ' years';
$txt['cd_month'] = ' month';
$txt['cd_months'] = ' months';
$txt['cd_day'] = ' day';
$txt['cd_days'] = ' days';
$txt['cd_hour'] = ' hour';
$txt['cd_hours'] = ' hours';
$txt['cd_minute'] = ' minute';
$txt['cd_minutes'] = ' minutes';
$txt['cd_remaning'] = ' remaining.';